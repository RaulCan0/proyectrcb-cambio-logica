import 'package:applensys/evaluacion/screens/shingo_result.dart';


class ShingoResultService {

  static final ShingoResultService _instance = ShingoResultService._internal();
  factory ShingoResultService() => _instance;
  ShingoResultService._internal();

  final Map<String, ShingoResultData> _resultados = {
    for (var label in sheetLabels) label: ShingoResultData(),
  };

  // Almacena porcentaje y puntos por hoja
  final Map<String, int> _porcentajes = {};
  final Map<String, int> _puntos = {};

  Map<String, ShingoResultData> get resultados => _resultados;

  void guardarResultado(String label, ShingoResultData data) {
    _resultados[label] = data;
  }

  void guardarPorcentajeYPuntos(String label, int porcentaje, int puntos) {
    _porcentajes[label] = porcentaje;
    _puntos[label] = puntos;
  }

  int? getCalificacion(String label) => _resultados[label]?.calificacion;

  int getPorcentaje(String label) => _porcentajes[label] ?? 0;
  int getPuntos(String label) => _puntos[label] ?? 0;
}