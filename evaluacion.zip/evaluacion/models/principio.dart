
import 'comportamiento.dart';

class Principio {
  final String id;
  final String dimensionId;
  final String nombre;
  final double promedioporcargo;
  final List<Comportamiento> comportamientos;

  Principio({
    required this.id,
    required this.dimensionId,
    required this.nombre,
    required this.promedioporcargo,
    required this.comportamientos,
  });
}
