// ignore_for_file: use_build_context_synchronously

import 'package:applensys/evaluacion/screens/tablas_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';

import '../models/calificacion.dart';
import '../models/principio_json.dart';
import '../services/calificacion_service.dart';
import '../services/storage_service.dart';
import '../services/supabase_service.dart';
import '../widgets/sistemas_asociados.dart';
import '../widgets/drawer_lensys.dart';
import '../providers/text_size_provider.dart';

/// 🔹 Sistemas sugeridos por comportamiento
const Map<String, String> sistemasRecomendadosPorComportamiento = {
  "Soporte": "Desarrollo de personas, Medición, Reconocimiento",
  "Reconocer":
      "Medición, Involucramiento, Reconocimiento, Desarrollo de Personas",
  "Comunidad": "Seguridad, Ambiental, EHS, Compromiso, Desarrollo de Personas",
  "Liderazgo de Servidor": "Desarrollo de Personas",
  "Valorar": "Desarrollo de Personas, Involucramiento",
  "Empoderar": "Medición, Reconocimiento, Desarrollo de Personas",
  "Mentalidad": "Sistemas de Mejora",
  "Estructura": "Sistemas de Mejora",
  "Reflexionar": "Solución de Problemas",
  "Análisis": "Solución de Problemas",
  "Colaborar": "Solución de Problemas",
  "Comprender": "Solución de Problemas, Gestión Visual",
  "Diseño": "Sistemas de Mejora, Gestión Visual",
  "Atribución": "Sistemas de Mejora, Solución de Problemas",
  "A prueba de Errores": "Sistemas de Mejora, Solución de Problemas",
  "Propiedad": "Sistemas de Mejora, Solución de Problemas",
  "Conectar": "Sistemas de Mejora",
  "Ininterrumpido": "Planificación y Programación, Sistemas de Mejora",
  "Demanda": "Planificación y Programación",
  "Eliminar": "Voz de Cliente, Sistemas de Mejora",
  "Optimizar": "Sistemas de Mejora, Despliegue de Estrategia",
  "Impacto": "Sistemas de Mejora",
  "Alinear": "Despliegue de Estrategia",
  "Aclarar": "Comunicación, Despliegue de Estrategia",
  "Comunicar": "Comunicación, Despliegue de Estrategia",
  "Relación": "Voz del Cliente",
  "Valor": "Voz del Cliente",
  "Medida":
      "Despliegue de Estrategia, Medición, Voz del Cliente, Recompensas, Reconocimientos",
};

/// 🔹 Normaliza strings como "d2", "D3", "2" -> 1..3
int _dimensionNumero(String raw) {
  final m = RegExp(r'\d+').firstMatch(raw);
  final n = int.tryParse(m?.group(0) ?? '') ?? 1;
  return (n < 1 || n > 3) ? 1 : n;
}

/// 🔹 Retorna "Dimensión N"
String obtenerNombreDimensionInterna(String raw) {
  switch (_dimensionNumero(raw)) {
    case 2:
      return 'Dimensión 2';
    case 3:
      return 'Dimensión 3';
    default:
      return 'Dimensión 1';
  }
}

class ComportamientoEvaluacionScreen extends ConsumerStatefulWidget {
  final PrincipioJson principio;
  final String cargo;
  final String evaluacionId;
  final String dimensionId; // puede venir "d1"/"1"
  final String empresaId;
  final String asociadoId;
  final Calificacion? calificacionExistente;

  const ComportamientoEvaluacionScreen({
    super.key,
    required this.principio,
    required this.cargo,
    required this.evaluacionId,
    required this.dimensionId,
    required this.empresaId,
    required this.asociadoId,
    this.calificacionExistente,
  });

  @override
  ConsumerState<ComportamientoEvaluacionScreen> createState() =>
      _ComportamientoEvaluacionScreenState();
}

class _ComportamientoEvaluacionScreenState
    extends ConsumerState<ComportamientoEvaluacionScreen> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  final calificacionService = CalificacionService();
  final supabaseService = SupabaseService();
  final storageService = StorageService();
  final _picker = ImagePicker();

  late int calificacion;
  final observacionController = TextEditingController();
  List<String> sistemasSeleccionados = [];
  bool isSaving = false;
  String? evidenciaUrl;

  @override
  void initState() {
    super.initState();
    if (widget.calificacionExistente != null) {
      final c = widget.calificacionExistente!;
      calificacion = c.puntaje;
      observacionController.text = c.observaciones ?? '';
      sistemasSeleccionados = List<String>.from(c.sistemas);
      evidenciaUrl = c.evidenciaUrl;
    } else {
      calificacion = 0;
    }
  }

  /// 📸 Subir evidencia
  Future<void> _takePhoto() async {
    try {
      final XFile? photo = await _picker.pickImage(source: ImageSource.gallery);
      if (photo == null) return;
      final bytes = await photo.readAsBytes();
      final fileName = const Uuid().v4();

      await storageService.uploadFile(
        bucket: 'evidencias',
        path: fileName,
        bytes: bytes,
        contentType: 'image/jpeg',
      );

      evidenciaUrl = storageService.getPublicUrl(
        bucket: 'evidencias',
        path: fileName,
      );
      setState(() {});
      _showAlert('Evidencia', 'Imagen subida correctamente.');
    } catch (e) {
      _showAlert('Error', 'No se pudo obtener la imagen: $e');
    }
  }

  /// 💾 Guardar evaluación
  Future<void> _guardarEvaluacion() async {
    final obs = observacionController.text.trim();
    if (obs.isEmpty) {
      _showAlert('Validación', 'Debes escribir una observación.');
      return;
    }
    if (sistemasSeleccionados.isEmpty) {
      _showAlert('Validación', 'Selecciona al menos un sistema.');
      return;
    }

    setState(() => isSaving = true);
    try {
      final comp =
          widget.principio.benchmarkComportamiento.split(':').first.trim();
      final dimIdNum = _dimensionNumero(widget.dimensionId);

      final existente =
          widget.calificacionExistente ??
          await calificacionService.getCalificacionExistente(
            idAsociado: widget.asociadoId,
            idEmpresa: widget.empresaId,
            idDimension: dimIdNum,
            comportamiento: comp,
          );

      final calObj = Calificacion(
        id: existente?.id ?? const Uuid().v4(),
        idAsociado: widget.asociadoId,
        idEmpresa: widget.empresaId,
        idDimension: dimIdNum,
        comportamiento: comp,
        puntaje: calificacion,
        fechaEvaluacion: DateTime.now(),
        observaciones: obs,
        sistemas: sistemasSeleccionados,
        evidenciaUrl: evidenciaUrl,
        principio: widget.principio.nombre,
      );

      if (existente != null) {
        await calificacionService.updateCalificacionFull(calObj);
      } else {
        await calificacionService.addCalificacion(calObj);
      }

      await TablasDimensionScreen.actualizarDato(
        dimension: obtenerNombreDimensionInterna(widget.dimensionId),
        principio: widget.principio.nombre,
        comportamiento: comp,
        cargo: widget.cargo,
        valor: calificacion,
        sistemas: sistemasSeleccionados,
        dimensionId: widget.dimensionId,
        asociadoId: widget.asociadoId,
        observaciones: obs,
        empresaId: widget.empresaId,
      );

      if (mounted) Navigator.pop(context, comp);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error al guardar: $e')));
      }
    } finally {
      if (mounted) setState(() => isSaving = false);
    }
  }

  void _showAlert(String title, String message) {
    showDialog<void>(
      context: context,
      builder:
          (_) => AlertDialog(
            title: Text(title),
            content: Text(message),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cerrar'),
              ),
            ],
          ),
    );
  }

  /// 📊 Tabla de lentes de madurez
  Widget _buildLentesDataTable(double scaleFactor) {
    DataCell wrap(String text) => DataCell(
      ConstrainedBox(
        constraints: BoxConstraints(maxWidth: 280 * scaleFactor),
        child: Text(
          text,
          softWrap: true,
          style: TextStyle(fontSize: 13 * scaleFactor),
        ),
      ),
    );

    return DataTable(
      columnSpacing: 10.0 * scaleFactor,
      headingRowHeight: 36 * scaleFactor,
      headingTextStyle: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 12 * scaleFactor,
        color: const Color(0xFF003056),
      ),
      columns: const [
        DataColumn(label: Text('Lentes / Rol')),
        DataColumn(label: Text('Nivel 1')),
        DataColumn(label: Text('Nivel 2')),
        DataColumn(label: Text('Nivel 3')),
        DataColumn(label: Text('Nivel 4')),
        DataColumn(label: Text('Nivel 5')),
      ],
      rows: [
        DataRow(
          cells: [
            const DataCell(Text('Ejecutivos')),
            wrap('Se centran en apagar fuegos.'),
            wrap('Conscientes pero no involucrados.'),
            wrap('Definen dirección y respaldan.'),
            wrap('Participan en mejora alineada.'),
            wrap('Garantizan principios arraigados.'),
          ],
        ),
        DataRow(
          cells: [
            const DataCell(Text('Gerentes')),
            wrap('Orientados a resultados inmediatos.'),
            wrap('Delegan mejoras en especialistas.'),
            wrap('Ayudan en diseño de sistemas.'),
            wrap('Enfocados en mejora diaria.'),
            wrap('Lideran mejora cultural.'),
          ],
        ),
        DataRow(
          cells: [
            const DataCell(Text('Miembros')),
            wrap('Sólo hacen su trabajo.'),
            wrap('Participan esporádicamente.'),
            wrap('Formados en proyectos.'),
            wrap('Usan herramientas diario.'),
            wrap('Lideran y enseñan principios.'),
          ],
        ),
      ],
    );
  }

  void _mostrarLentesDialog(double scaleFactor) {
    showDialog<void>(
      context: context,
      builder:
          (_) => AlertDialog(
            title: const Text('Lentes de madurez'),
            content: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: _buildLentesDataTable(scaleFactor),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cerrar'),
              ),
            ],
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final textSize = ref.watch(textSizeProvider);
    final double scaleFactor = textSize / 14.0;
    final desc =
        widget.principio.calificaciones['C$calificacion'] ??
        'Desliza para calificar';
    final comp =
        widget.principio.benchmarkComportamiento.split(':').first.trim();

    return Scaffold(
      key: _scaffoldKey,
      endDrawer: const DrawerLensys(),
      appBar: AppBar(
        backgroundColor: const Color(0xFF003056),
        title: Text(
          widget.principio.nombre,
          style: const TextStyle(color: Colors.white),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.remove_red_eye),
            onPressed: () => _mostrarLentesDialog(scaleFactor),
          ),
          IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () => _scaffoldKey.currentState?.openEndDrawer(),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Benchmark: ${widget.principio.benchmarkPorNivel}'),
            const SizedBox(height: 8),
            Slider(
              value: calificacion.toDouble(),
              min: 0,
              max: 5,
              divisions: 5,
              label: calificacion.toString(),
              onChanged:
                  isSaving
                      ? null
                      : (v) => setState(() => calificacion = v.round()),
            ),
            Text(desc),
            const SizedBox(height: 12),
            // 🔹 Sistemas sugeridos
            if (sistemasRecomendadosPorComportamiento.containsKey(comp))
              Text(
                'Sistemas sugeridos: ${sistemasRecomendadosPorComportamiento[comp]}',
                style: const TextStyle(
                  color: Color(0xFF003056),
                  fontWeight: FontWeight.bold,
                ),
              ),
            const SizedBox(height: 12),
            TextField(
              controller: observacionController,
              maxLines: 2,
              enabled: !isSaving,
              decoration: const InputDecoration(
                hintText: 'Observaciones...',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              icon: const Icon(Icons.settings),
              label: const Text('Sistemas asociados'),
              onPressed:
                  isSaving
                      ? null
                      : () async {
                        final seleccion =
                            await showModalBottomSheet<List<String>>(
                              context: context,
                              builder:
                                  (_) => SistemasScreen(
                                    onSeleccionar:
                                        (s) => Navigator.pop(
                                          context,
                                          s
                                              .map(
                                                (e) => e['nombre'].toString(),
                                              )
                                              .toList(),
                                        ),
                                  ),
                            );
                        if (seleccion != null) {
                          setState(() => sistemasSeleccionados = seleccion);
                        }
                      },
            ),
            if (sistemasSeleccionados.isNotEmpty)
              Wrap(
                spacing: 8,
                children:
                    sistemasSeleccionados
                        .map(
                          (s) => Chip(
                            label: Text(s),
                            onDeleted:
                                () => setState(
                                  () => sistemasSeleccionados.remove(s),
                                ),
                          ),
                        )
                        .toList(),
              ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              icon: const Icon(Icons.camera_alt),
              label: const Text('Subir evidencia'),
              onPressed: isSaving ? null : _takePhoto,
            ),
            if (evidenciaUrl != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Image.network(evidenciaUrl!, height: 160),
              ),
            const SizedBox(height: 24),
            Center(
              child: ElevatedButton.icon(
                icon:
                    isSaving
                        ? const CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        )
                        : const Icon(Icons.save),
                label: Text(isSaving ? 'Guardando...' : 'Guardar Evaluación'),
                onPressed: isSaving ? null : _guardarEvaluacion,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
