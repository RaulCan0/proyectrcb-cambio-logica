
import 'package:flutter/material.dart';
import 'package:applensys/evaluacion/models/asociado.dart';
import 'package:applensys/evaluacion/models/calificacion.dart';

class EvaluacionProvider extends ChangeNotifier {
  Map<String, Map<String, List<Map<String, dynamic>>>> tablaDatos = {
    'Dimensión 1': {},
    'Dimensión 2': {},
    'Dimensión 3': {},
  };

  Map<String, double> progresoAsociado = {};
  
  // Nuevo: Clasificación por asociados y niveles
  final Map<String, AsociadoEvaluacionData> _evaluacionesPorAsociado = {};
  final Map<String, String> _cargoNormalizado = {};

  void actualizarTabla(String dimension, String categoria, Map<String, dynamic> dato) {
    if (!tablaDatos.containsKey(dimension)) {
      tablaDatos[dimension] = {};
    }
    if (!tablaDatos[dimension]!.containsKey(categoria)) {
      tablaDatos[dimension]![categoria] = [];
    }
    tablaDatos[dimension]![categoria]!.add(dato);
    
    // Clasificar por asociado si tiene la información necesaria
    _clasificarPorAsociado(dato, dimension, categoria);
    
    notifyListeners();
  }

  void actualizarProgreso(String dimension, double progreso) {
    progresoAsociado[dimension] = progreso;
    notifyListeners();
  }

  void reiniciarDatos() {
    tablaDatos.clear();
    progresoAsociado.clear();
    _evaluacionesPorAsociado.clear();
    _cargoNormalizado.clear();
    notifyListeners();
  }

  /// Clasifica las evaluaciones por asociado y nivel
  void _clasificarPorAsociado(Map<String, dynamic> dato, String dimension, String categoria) {
    final asociadoId = dato['asociado_id'] as String?;
    final cargoRaw = dato['cargo_raw'] as String?;
    
    if (asociadoId == null || cargoRaw == null) return;

    // Normalizar cargo
    final cargoNormalizado = _normalizarCargo(cargoRaw);
    
    // Crear o actualizar datos del asociado
    if (!_evaluacionesPorAsociado.containsKey(asociadoId)) {
      _evaluacionesPorAsociado[asociadoId] = AsociadoEvaluacionData(
        asociadoId: asociadoId,
        nivel: cargoNormalizado,
        evaluacionesPorDimension: {},
      );
    }

    final asociadoData = _evaluacionesPorAsociado[asociadoId]!;
    
    // Agregar evaluación a la dimensión correspondiente
    if (!asociadoData.evaluacionesPorDimension.containsKey(dimension)) {
      asociadoData.evaluacionesPorDimension[dimension] = [];
    }
    
    asociadoData.evaluacionesPorDimension[dimension]!.add(dato);
  }

  /// Normaliza el cargo a uno de los tres niveles
  String _normalizarCargo(String cargoRaw) {
    if (_cargoNormalizado.containsKey(cargoRaw)) {
      return _cargoNormalizado[cargoRaw]!;
    }

    final cargoLower = cargoRaw.toLowerCase().trim();
    String nivel;

    if (cargoLower.contains('ejecutivo') || 
        cargoLower.contains('director') || 
        cargoLower.contains('gerente general') ||
        cargoLower.contains('presidente') ||
        cargoLower.contains('ceo')) {
      nivel = 'Ejecutivo';
    } else if (cargoLower.contains('gerente') || 
               cargoLower.contains('manager') ||
               cargoLower.contains('supervisor') ||
               cargoLower.contains('coordinador') ||
               cargoLower.contains('jefe')) {
      nivel = 'Gerente';
    } else {
      nivel = 'Miembro';
    }

    _cargoNormalizado[cargoRaw] = nivel;
    return nivel;
  }

  /// Obtiene evaluaciones clasificadas por nivel
  Map<String, List<AsociadoEvaluacionData>> getEvaluacionesPorNivel() {
    final Map<String, List<AsociadoEvaluacionData>> clasificadas = {
      'Ejecutivo': [],
      'Gerente': [],
      'Miembro': [],
    };

    for (final evaluacion in _evaluacionesPorAsociado.values) {
      if (clasificadas.containsKey(evaluacion.nivel)) {
        clasificadas[evaluacion.nivel]!.add(evaluacion);
      }
    }

    return clasificadas;
  }

  /// Obtiene estadísticas por nivel
  Map<String, EstadisticasNivel> getEstadisticasPorNivel() {
    final evaluacionesPorNivel = getEvaluacionesPorNivel();
    final Map<String, EstadisticasNivel> estadisticas = {};

    for (final entry in evaluacionesPorNivel.entries) {
      final nivel = entry.key;
      final evaluaciones = entry.value;

      // Calcular promedios por dimensión para este nivel
      final Map<String, List<double>> valoresPorDimension = {};
      
      for (final evaluacion in evaluaciones) {
        for (final dimEntry in evaluacion.evaluacionesPorDimension.entries) {
          final dimension = dimEntry.key;
          final datos = dimEntry.value;
          
          for (final dato in datos) {
            final valor = (dato['valor'] as num?)?.toDouble() ?? 0.0;
            if (valor > 0) {
              valoresPorDimension.putIfAbsent(dimension, () => []).add(valor);
            }
          }
        }
      }

      // Calcular promedios finales
      final Map<String, double> promediosPorDimension = {};
      double sumaGeneral = 0.0;
      int conteoGeneral = 0;

      for (final entry in valoresPorDimension.entries) {
        final dimension = entry.key;
        final valores = entry.value;
        if (valores.isNotEmpty) {
          final promedio = valores.reduce((a, b) => a + b) / valores.length;
          promediosPorDimension[dimension] = promedio;
          sumaGeneral += promedio;
          conteoGeneral++;
        }
      }

      final promedioGeneral = conteoGeneral > 0 ? sumaGeneral / conteoGeneral : 0.0;

      estadisticas[nivel] = EstadisticasNivel(
        nombreNivel: nivel,
        totalAsociados: evaluaciones.length,
        promedioGeneral: promedioGeneral,
        promediosPorDimension: promediosPorDimension,
      );
    }

    return estadisticas;
  }

  /// Obtiene datos de un asociado específico
  AsociadoEvaluacionData? getEvaluacionAsociado(String asociadoId) {
    return _evaluacionesPorAsociado[asociadoId];
  }

  /// Obtiene el total de asociados por nivel
  Map<String, int> getTotalAsociadosPorNivel() {
    final evaluacionesPorNivel = getEvaluacionesPorNivel();
    return evaluacionesPorNivel.map((nivel, evaluaciones) => 
      MapEntry(nivel, evaluaciones.length));
  }
}

/// Clase para almacenar datos de evaluación de un asociado
class AsociadoEvaluacionData {
  final String asociadoId;
  final String nivel;
  final Map<String, List<Map<String, dynamic>>> evaluacionesPorDimension;

  AsociadoEvaluacionData({
    required this.asociadoId,
    required this.nivel,
    required this.evaluacionesPorDimension,
  });
}

/// Estadísticas agregadas por nivel
class EstadisticasNivel {
  final String nombreNivel;
  final int totalAsociados;
  final double promedioGeneral;
  final Map<String, double> promediosPorDimension;

  EstadisticasNivel({
    required this.nombreNivel,
    required this.totalAsociados,
    required this.promedioGeneral,
    required this.promediosPorDimension,
  });
}
