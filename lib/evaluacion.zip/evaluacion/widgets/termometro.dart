import 'package:flutter/material.dart';

class TermometroGlobal extends StatelessWidget {
  final double valorObtenido;
  final double valorMaximo;
  final String titulo;

  const TermometroGlobal({
    super.key,
    required this.valorObtenido,
    required this.valorMaximo,
    this.titulo = 'TERMÓMETRO GLOBAL',
  });

  @override
  Widget build(BuildContext context) {
    final valorEscalado = (valorObtenido / valorMaximo) * 1000;
    final fill = (valorEscalado / 1000).clamp(0.0, 1.0);
    final barWidth = MediaQuery.of(context).size.width - 32; // padding 16*2
    final indicatorX = barWidth * fill;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(titulo, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 4),
        Text('${valorEscalado.toStringAsFixed(0)} / 1000 pts'),
        const SizedBox(height: 8),
        Container(
          height: 24,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Colors.red, Colors.yellow, Colors.green],
            ),
            borderRadius: BorderRadius.circular(4),
          ),
          child: Stack(
            children: [
              Positioned(
                left: 0,
                width: indicatorX,
                top: 0,
                bottom: 0,
                child: Container(
                  decoration: BoxDecoration(
                    // ignore: deprecated_member_use
                    color: Colors.yellow.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
              Positioned(
                left: (indicatorX - 12).clamp(0.0, barWidth - 24),
                top: 0,
                bottom: 0,
                child: Center(
                  child: Tooltip(
                    message: '${valorEscalado.toStringAsFixed(0)} / 1000 pts',
                    child: Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.black26),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
