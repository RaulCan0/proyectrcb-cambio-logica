import 'package:applensys/evaluacion/models/asociado.dart';
class AsociadoService {
  Future<List<Asociado>> getAsociadosPorEmpresa(String empresaId) async {
    // Implementación pendiente o ajustada según necesidades
    throw UnimplementedError();
  }

  Future<void> addAsociado(Asociado asociado) async {
    // Implementación pendiente o ajustada según necesidades
    throw UnimplementedError();
  }

  Future<void> updateAsociado(String id, Asociado asociado) async {
    // Implementación pendiente o ajustada según necesidades
    throw UnimplementedError();
  }

  Future<void> deleteAsociado(String id) async {
    // Implementación pendiente o ajustada según necesidades
    throw UnimplementedError();
  }
}
