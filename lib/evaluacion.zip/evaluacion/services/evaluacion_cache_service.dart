import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class EvaluacionCacheService {
  static const _keyEvaluacionPendiente = 'evaluacion_pendiente';
  static const _keyTablaDatos = 'tabla_datos';

  static const _keyPromediosDimensiones = 'evaluacion_promedios_dimensiones';
  static const _keyPromediosPrincipios = 'evaluacion_promedios_principios';
  static const _keyPromediosComportamientos = 'evaluacion_promedios_comportamientos';
  static const _keyPromediosSistemas = 'evaluacion_promedios_sistemas';

  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
  }

  // === PENDIENTE ===
  Future<void> guardarPendiente(String evaluacionId) async {
    await init();
    await _prefs!.setString(_keyEvaluacionPendiente, evaluacionId);
  }

  Future<String?> obtenerPendiente() async {
    await init();
    return _prefs!.getString(_keyEvaluacionPendiente);
  }

  Future<void> eliminarPendiente() async {
    await init();
    await _prefs!.remove(_keyEvaluacionPendiente);
  }

  // === TABLAS DE CALIFICACIONES ===
  Future<void> guardarTablas(
      Map<String, Map<String, List<Map<String, dynamic>>>> data) async {
    await init();
    final encoded = jsonEncode(data);
    await _prefs!.setString(_keyTablaDatos, encoded);
  }

  Future<Map<String, Map<String, List<Map<String, dynamic>>>>> cargarTablas() async {
    await init();
    final raw = _prefs!.getString(_keyTablaDatos);
    if (raw == null || raw.isEmpty) {
      return {
        'Dimensión 1': {},
        'Dimensión 2': {},
        'Dimensión 3': {},
      };
    }

    try {
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      return decoded.map((dim, map) {
        final sub = (map as Map<String, dynamic>).map((id, filas) =>
            MapEntry(id, List<Map<String, dynamic>>.from(
              (filas as List).map((e) => Map<String, dynamic>.from(e)))));
        return MapEntry(dim, sub);
      });
    } catch (_) {
      return {
        'Dimensión 1': {},
        'Dimensión 2': {},
        'Dimensión 3': {},
      };
    }
  }

  Future<void> limpiarCacheTablaDatos() async {
    await init();
    await _prefs!.remove(_keyTablaDatos);
  }

  Future<void> limpiarEvaluacionCompleta() async {
    await init();
    await _prefs!.clear();
  }

  // === PROMEDIOS DIMENSIONES ===
  Future<void> guardarPromediosDimensiones(Map<String, Map<String, double>> data) async {
    await init();
    await _prefs!.setString(_keyPromediosDimensiones, jsonEncode(data));
  }

  Future<Map<String, Map<String, double>>> cargarPromediosDimensiones() async {
    await init();
    final raw = _prefs!.getString(_keyPromediosDimensiones);
    if (raw == null) return {};
    final decoded = jsonDecode(raw) as Map<String, dynamic>;
    return decoded.map((dim, principios) {
      final subMap = (principios as Map<String, dynamic>).map(
        (p, v) => MapEntry(p, (v as num).toDouble()),
      );
      return MapEntry(dim, subMap);
    });
  }

  // === PROMEDIOS PRINCIPIOS ===
  Future<void> guardarPromediosPrincipios(Map<String, Map<String, double>> data) async {
    await init();
    await _prefs!.setString(_keyPromediosPrincipios, jsonEncode(data));
  }

  Future<Map<String, Map<String, double>>> cargarPromediosPrincipios() async {
    await init();
    final raw = _prefs!.getString(_keyPromediosPrincipios);
    if (raw == null) return {};
    final decoded = jsonDecode(raw) as Map<String, dynamic>;
    return decoded.map((dim, principios) {
      final subMap = (principios as Map<String, dynamic>).map(
        (p, v) => MapEntry(p, (v as num).toDouble()),
      );
      return MapEntry(dim, subMap);
    });
  }

  // === PROMEDIOS COMPORTAMIENTOS ===
  Future<void> guardarPromediosComportamientos(Map<String, Map<String, double>> data) async {
    await init();
    await _prefs!.setString(_keyPromediosComportamientos, jsonEncode(data));
  }

  Future<Map<String, Map<String, double>>> cargarPromediosComportamientos() async {
    await init();
    final raw = _prefs!.getString(_keyPromediosComportamientos);
    if (raw == null) return {};
    final decoded = jsonDecode(raw) as Map<String, dynamic>;
    return decoded.map((dim, comps) {
      final subMap = (comps as Map<String, dynamic>).map(
        (c, v) => MapEntry(c, (v as num).toDouble()),
      );
      return MapEntry(dim, subMap);
    });
  }

  // === PROMEDIOS SISTEMAS ===
  Future<void> guardarPromediosSistemas(List<Map<String, dynamic>> data) async {
    await init();
    await _prefs!.setString(_keyPromediosSistemas, jsonEncode(data));
  }

  Future<List<Map<String, dynamic>>> cargarPromediosSistemas() async {
    await init();
    final raw = _prefs!.getString(_keyPromediosSistemas);
    if (raw == null) return [];
    final decoded = jsonDecode(raw) as List<dynamic>;
    return decoded.map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<void> guardarObservacionesShingo(Map<String, String> cast) async {}

  Future cargarObservacionesShingo() async {}
}
