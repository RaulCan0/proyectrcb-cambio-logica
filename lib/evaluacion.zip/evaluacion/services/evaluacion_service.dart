import 'package:applensys/evaluacion/models/emplado_evaluacion.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import '../models/empresa.dart';
import '../models/evaluacion_empresa.dart';
import '../models/calificacion.dart';

class EvaluacionEmpresaService {
  final SupabaseClient _client = Supabase.instance.client;

  // Crear empresa + evaluación activa + empleados + calificaciones vacías
  Future<void> registrarEmpresaConEvaluacion({
    required Empresa empresa,
    required List<EmpleadoEvaluacion> empleados,
  }) async {
    final empresaId = empresa.id;
    final evaluacionId = const Uuid().v4();
    final now = DateTime.now();

    // Insertar empresa
    await _client.from('empresas').insert(empresa.toMap());

    // Crear evaluación activa
    final evaluacion = EvaluacionEmpresa(
      id: evaluacionId,
      idEmpresa: empresaId,
      empresaNombre: empresa.nombre,
      fecha: now,
    );
    await _client.from('evaluaciones_empresa').insert(evaluacion.toJson());

    // Insertar empleados evaluados y calificaciones vacías
    for (final empleado in empleados) {
      final empleadoFinal = EmpleadoEvaluacion(
        evaluacionId: evaluacionId,
        nombreCompleto: empleado.nombreCompleto,
        antiguedad: empleado.antiguedad,
        puesto: empleado.puesto,
        cargo: empleado.cargo,
      );

      await _client.from('empleados_evaluacion').insert(empleadoFinal.toJson());

      final comportamientos = [
        'Liderazgo', 'Colaboración', 'Comunicación', 'Innovación'
      ];

      for (final comportamiento in comportamientos) {
        final calificacion = CalificacionComportamiento(
          evaluacionId: evaluacionId,
          idEmpleado: empleadoFinal.id,
          comportamiento: comportamiento,
          cargo: empleadoFinal.cargo,
          puntaje: 0,
          observacion: '',
          fechaEvaluacion: now, idDimension: '', principio: '',
        );

        await _client.from('calificaciones').insert(calificacion.toJson());
      }
    }
  }

  // Obtener empresas
  Future<List<Empresa>> cargarEmpresas() async {
    final res = await _client.from('empresas').select();
    return (res as List).map((e) => Empresa.fromMap(e)).toList();
  }

  // Editar empresa
  Future<void> editarEmpresa(Empresa empresa) async {
    await _client.from('empresas').update(empresa.toMap()).eq('id', empresa.id);
  }

  // Eliminar empresa (y cascada si aplica)
  Future<void> eliminarEmpresa(String empresaId) async {
    await _client.from('empresas').delete().eq('id', empresaId);
  }

  // Obtener evaluación activa
  Future<EvaluacionEmpresa?> obtenerEvaluacionActiva(String empresaId) async {
    final res = await _client
        .from('evaluaciones_empresa')
        .select()
        .eq('empresa_id', empresaId)
        .eq('finalizada', false)
        .order('fecha', ascending: false)
        .limit(1);

    if (res.isEmpty) return null;
    return EvaluacionEmpresa.fromJson(res.first);
  }

  // Finalizar evaluación
  Future<void> finalizarEvaluacion(String evaluacionId) async {
    await _client
        .from('evaluaciones_empresa')
        .update({'finalizada': true})
        .eq('id', evaluacionId);
  }

  // Calificaciones por evaluación
  Future<List<CalificacionComportamiento>> getCalificacionesPorEvaluacion(String evaluacionId) async {
    final res = await _client
        .from('calificaciones')
        .select()
        .eq('evaluacion_id', evaluacionId);
    return (res as List).map((e) => CalificacionComportamiento.fromJson(e)).toList();
  }

  // Editar solo campos válidos de calificación
  Future<void> updateCalificacionEditable(CalificacionComportamiento c) async {
    await _client.from('calificaciones').update({
      'puntaje': c.puntaje,
      'observacion': c.observacion,
      'sistemas_asociados': c.sistemasAsociados,
      'evidencia_url': c.evidenciaUrl,
    }).eq('id', c.id);
  }

  // Obtener empleados de una evaluación
  Future<List<EmpleadoEvaluacion>> getEmpleadosDeEvaluacion(String evaluacionId) async {
    final res = await _client
        .from('empleados_evaluacion')
        .select()
        .eq('evaluacion_id', evaluacionId);
    return (res as List).map((e) => EmpleadoEvaluacion.fromJson(e)).toList();
  }
}
