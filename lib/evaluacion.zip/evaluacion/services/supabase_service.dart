// Supabase Service para Empresas, Evaluaciones, Empleados y Calificaciones

import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../models/empresa.dart';
import '../models/evaluacion_empresa.dart';
import '../models/emplado_evaluacion.dart';
import '../models/calificacion.dart';

class SupabaseService {
  final SupabaseClient _client = Supabase.instance.client;

  /// Crear una nueva empresa y su evaluación activa
  Future<void> crearEmpresaConEvaluacion(Empresa empresa, List<EmpleadoEvaluacion> empleados) async {
    final String empresaId = empresa.id;
    final String evaluacionId = const Uuid().v4();

    await _client.from('empresas').insert(empresa.toMap());

    final evaluacion = EvaluacionEmpresa(
      id: evaluacionId,
      idEmpresa: empresa.id,
      empresaNombre: empresa.nombre,
      fecha: DateTime.now(),
      puntosDimensiones: 0,
      puntosResultados: 0,
      finalizada: false, 
    );

    await _client.from('evaluaciones').insert(evaluacion.toJson());

    // Insertar empleados vinculados a esta evaluación
    for (final empleado in empleados) {
      final empEval = {
        'id': empleado.id,
        'evaluacion_id': evaluacionId,
        'nombre_completo': empleado.nombreCompleto,
        'puesto': empleado.puesto,
        'cargo': empleado.cargo,
        'antiguedad': empleado.antiguedad,
      };
      await _client.from('empleados_evaluacion').insert(empEval);
    }
  }

  /// Eliminar empresa (y relaciones si aplica)
  Future<void> eliminarEmpresa(String empresaId) async {
    await _client.from('empresas').delete().eq('id', empresaId);
  }

  /// Obtener todas las empresas
  Future<List<Empresa>> getEmpresas() async {
    final res = await _client.from('empresas').select();
    return (res as List).map((e) => Empresa.fromMap(e)).toList();
  }

  /// Agregar calificación
  Future<void> addCalificacion(
    CalificacionComportamiento calificacion, {
    required String id,
    required String idEmpleado,
  }) async {
    await _client.from('calificaciones').insert(calificacion.toJson());
  }

  /// Editar solo puntaje
  Future<void> updateCalificacion(String id, int nuevoPuntaje) async {
    await _client.from('calificaciones').update({'puntaje': nuevoPuntaje}).eq('id', id);
  }

  /// Editar campos específicos
  Future<void> updateEditableCalificacionFields({
    required String id,
    required int puntaje,
    String? observacion,
    List<String>? sistemasAsociados,
    String? evidenciaUrl,
  }) async {
    await _client.from('calificaciones').update({
      'puntaje': puntaje,
      'observacion': observacion,
      'sistemas_asociados': sistemasAsociados,
      'evidencia_url': evidenciaUrl,
    }).eq('id', id);
  }

  /// Eliminar calificación
  Future<void> deleteCalificacion(String id) async {
    await _client.from('calificaciones').delete().eq('id', id);
  }

  /// Obtener calificaciones por asociado
  Future<List<CalificacionComportamiento>> getCalificacionesPorAsociado(String idEmpleado) async {
    final res = await _client.from('calificaciones').select().eq('empleado_id', idEmpleado);
    return (res as List).map((e) => CalificacionComportamiento.fromJson(e)).toList();
  }

  /// Obtener calificaciones por evaluación
  Future<List<CalificacionComportamiento>> getCalificacionesPorEvaluacion(String evaluacionId) async {
    final res = await _client.from('calificaciones').select().eq('evaluacion_id', evaluacionId);
    return (res as List).map((e) => CalificacionComportamiento.fromJson(e)).toList();
  }
}
