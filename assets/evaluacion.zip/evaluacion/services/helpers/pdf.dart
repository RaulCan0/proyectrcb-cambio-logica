import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

class NivelEvaluacion {
  final double promedio;
  final String interpretacion; // Del JSON según calificación (C1-C5)
  final String benchmarkPorCargo; // Del JSON según comportamiento y cargo
  final String obs;
  final List<String> sistemasSeleccionados;

  NivelEvaluacion({
    required this.promedio,
    required this.interpretacion,
    required this.benchmarkPorCargo,
    required this.obs,
    required this.sistemasSeleccionados,
  });
}

class ReporteComportamiento {
  final String nombre;
  final Map<String, NivelEvaluacion> niveles; // E, G, M

  ReporteComportamiento({
    required this.nombre,
    required this.niveles,
  });
}

class ReportePdfService {
  static Future<Uint8List> generarReportePdf(List<ReporteComportamiento> datos) async {
    final pdf = pw.Document();

    final textStyle = pw.TextStyle(fontSize: 10);
    final headerStyle = pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold);

    for (final comp in datos) {
      pdf.addPage(
        pw.Page(
          build: (context) => pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text("Comportamiento: ${comp.nombre}", style: headerStyle),
              pw.SizedBox(height: 6),
              _fila("Nivel", "Promedio", "Interpretación", "Benchmark por Cargo", "Sistemas", "Hallazgos", isHeader: true),
              for (final nivel in ["E", "G", "M"])
                if (comp.niveles[nivel] != null)
                  _fila(
                    nivel == "E" ? "Ejecutivo" : nivel == "G" ? "Gerente" : "Miembro",
                    comp.niveles[nivel]!.promedio.toStringAsFixed(2),
                    comp.niveles[nivel]!.interpretacion,
                    comp.niveles[nivel]!.benchmarkPorCargo,
                    comp.niveles[nivel]!.sistemasSeleccionados.join(", "),
                    comp.niveles[nivel]!.obs,
                  ),
              pw.Divider(),
            ],
          ),
        ),
      );
    }

    // Página final con resumen gráfico
    pdf.addPage(
      pw.Page(
        build: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text("Resumen Gráfico de Promedios", style: headerStyle),
            pw.SizedBox(height: 20),
            _buildBarChart(datos),
          ],
        ),
      ),
    );

    return pdf.save();
  }

  static pw.Widget _fila(String nivel, String promedio, String interp, String benchmark, String sistemas, String hallazgos, {bool isHeader = false}) {
    final style = pw.TextStyle(fontSize: isHeader ? 10 : 9, fontWeight: isHeader ? pw.FontWeight.bold : pw.FontWeight.normal);
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(vertical: 4),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Expanded(flex: 1, child: pw.Text(nivel, style: style)),
          pw.Expanded(flex: 1, child: pw.Text(promedio, style: style)),
          pw.Expanded(flex: 1, child: pw.Text(interp, style: style)),
          pw.Expanded(flex: 3, child: pw.Text(benchmark, style: style)),
          pw.Expanded(flex: 2, child: pw.Text(sistemas, style: style)),
          pw.Expanded(flex: 3, child: pw.Text(hallazgos, style: style)),
        ],
      ),
    );
  }

  static pw.Widget _buildBarChart(List<ReporteComportamiento> data) {
    final labels = <String>[];
    final eData = <double>[];
    final gData = <double>[];
    final mData = <double>[];

    for (final comp in data) {
      labels.add(comp.nombre.length > 10 ? comp.nombre.substring(0, 10) : comp.nombre);
      eData.add(comp.niveles['E']?.promedio ?? 0);
      gData.add(comp.niveles['G']?.promedio ?? 0);
      mData.add(comp.niveles['M']?.promedio ?? 0);
    }

    return pw.Column(
      children: [
        for (int i = 0; i < labels.length; i++)
          pw.Row(
            children: [
              pw.Container(width: 60, child: pw.Text(labels[i], style: pw.TextStyle(fontSize: 8))),
              _bar(eData[i], PdfColors.red),
              _bar(gData[i], PdfColors.green),
              _bar(mData[i], PdfColors.blue),
            ],
          ),
      ],
    );
  }

  static pw.Widget _bar(double value, PdfColor color) {
    return pw.Container(
      margin: const pw.EdgeInsets.symmetric(horizontal: 2, vertical: 2),
      height: 10,
      width: value * 20, // Escala visual
      color: color,
    );
  }
}




/*import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;


class NivelEvaluacion {
  final double promedio;
  final String interpretacion;
  final String benchmark;
  final String obs;
  final List<String> sistemasseleccionados;

  NivelEvaluacion({
    required this.promedio,
    required this.interpretacion,
    required this.benchmark,
    required this.obs,
    required this.sistemasseleccionados,
  });
}

class ReporteComportamiento {
  final String nombre;
  final Map<String, NivelEvaluacion> niveles; // E, G, M

  ReporteComportamiento({
    required this.nombre,
    required this.niveles,
  });
}

class ReportePdfGenerator {
  static Future<Uint8List> generar(List<ReporteComportamiento> datos) async {
    final pdf = pw.Document();

    final textStyle = pw.TextStyle(fontSize: 10);
    final headerStyle = pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold);

    for (final comp in datos) {
      pdf.addPage(
        pw.Page(
          build: (context) => pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text("Comportamiento: ${comp.nombre}", style: headerStyle),
              pw.SizedBox(height: 6),
              _fila("Nivel", "Promedio", "Interpretación", "Benchmark", "Sistemas", "Hallazgos", isHeader: true),
              for (final nivel in ["E", "G", "M"])
                if (comp.niveles[nivel] != null)
                  _fila(
                    nivel == "E" ? "Ejecutivo" : nivel == "G" ? "Gerente" : "Miembro",
                    comp.niveles[nivel]!.promedio.toStringAsFixed(2),
                    comp.niveles[nivel]!.interpretacion,
                    comp.niveles[nivel]!.benchmark,
                    comp.niveles[nivel]!.sistemas.join(", "),
                    comp.niveles[nivel]!.hallazgos,
                  ),
              pw.Divider(),
            ],
          ),
        ),
      );
    }

    // GRÁFICO
    pdf.addPage(
      pw.Page(
        build: (context) => pw.Column(
          children: [
            pw.Text("Resumen Gráfico de Promedios", style: headerStyle),
            pw.SizedBox(height: 20),
            _buildBarChart(datos),
          ],
        ),
      ),
    );

    return pdf.save();
  }

  static pw.Widget _fila(String nivel, String promedio, String interp, String benchmark, String sistemas, String hallazgos, {bool isHeader = false}) {
    final style = pw.TextStyle(fontSize: isHeader ? 10 : 9, fontWeight: isHeader ? pw.FontWeight.bold : pw.FontWeight.normal);
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(vertical: 4),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Expanded(flex: 1, child: pw.Text(nivel, style: style)),
          pw.Expanded(flex: 1, child: pw.Text(promedio, style: style)),
          pw.Expanded(flex: 1, child: pw.Text(interp, style: style)),
          pw.Expanded(flex: 3, child: pw.Text(benchmark, style: style)),
          pw.Expanded(flex: 2, child: pw.Text(sistemas, style: style)),
          pw.Expanded(flex: 3, child: pw.Text(hallazgos, style: style)),
        ],
      ),
    );
  }

  static pw.Widget _buildBarChart(List<ReporteComportamiento> data) {
    final labels = <String>[];
    final eData = <double>[];
    final gData = <double>[];
    final mData = <double>[];

    for (final comp in data) {
      labels.add(comp.nombre.length > 10 ? comp.nombre.substring(0, 10) : comp.nombre);
      eData.add(comp.niveles['E']?.promedio ?? 0);
      gData.add(comp.niveles['G']?.promedio ?? 0);
      mData.add(comp.niveles['M']?.promedio ?? 0);
    }

    return pw.Column(
      children: [
        for (int i = 0; i < labels.length; i++)
          pw.Row(
            children: [
              pw.Container(width: 60, child: pw.Text(labels[i], style: pw.TextStyle(fontSize: 8))),
              _bar(eData[i], PdfColors.red),
              _bar(gData[i], PdfColors.green),
              _bar(mData[i], PdfColors.blue),
            ],
          ),
      ],
    );
  }

  static pw.Widget _bar(double value, PdfColor color) {
    return pw.Container(
      margin: const pw.EdgeInsets.symmetric(horizontal: 2, vertical: 2),
      height: 10,
      width: value * 20, // Escala visual
      color: color,
    );
  }
}*/