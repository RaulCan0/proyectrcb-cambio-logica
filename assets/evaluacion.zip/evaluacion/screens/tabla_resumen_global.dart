import 'package:applensys/evaluacion/widgets/tabla_puntuacion_global.dart';
import 'package:flutter/material.dart';
import '../widgets/tabla_shingo.dart';

class TablaResumenGlobal extends StatelessWidget {
  final Map<String, Map<String, double>> promediosPorDimension;
  final Map<String, ShingoResultData> resultadosShingo;

  const TablaResumenGlobal({
    super.key,
    required this.promediosPorDimension,
    required this.resultadosShingo,
  });

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Score Global'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Puntuación Global'),
              Tab(text: 'Resultados Shingo'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: TablaPuntuacionGlobal(
                promediosPorDimension: promediosPorDimension,
              ),
            ),
            SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: TablaResultadosShingo(
                resultados: resultadosShingo,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
